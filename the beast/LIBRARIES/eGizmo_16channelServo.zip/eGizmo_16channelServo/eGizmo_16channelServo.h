#ifndef eGizmo_16channelServo_h
#define eGizmo_16channelServo_h


#include <Arduino.h>
#include <SoftwareSerial.h>

#define preFix 0x02
#define sufFix 0x03

#define SERVO0 0
#define SERVO1 1
#define SERVO2 2
#define SERVO3 3
#define SERVO4 4
#define SERVO5 5
#define SERVO6 6
#define SERVO7 7
#define SERVO8 8
#define SERVO9 9
#define SERVO10 10
#define SERVO11 11
#define SERVO12 12
#define SERVO13 13
#define SERVO14 14
#define SERVO15 15
#define SERVO16 16
#define SERVO17 17
#define SERVO18 18
#define SERVO19 19
#define SERVO20 20
#define SERVO21 21
#define SERVO22 22
#define SERVO23 23
#define SERVO24 24
#define SERVO25 25
#define SERVO26 26
#define SERVO27 27
#define SERVO28 28
#define SERVO29 29
#define SERVO30 30
#define SERVO31 31
#define SERVO32 32
#define SERVO33 33
#define SERVO34 34
#define SERVO35 35
#define SERVO36 36
#define SERVO37 37
#define SERVO38 38
#define SERVO39 39
#define SERVO40 40
#define SERVO41 41
#define SERVO42 42
#define SERVO43 43
#define SERVO44 44
#define SERVO45 45
#define SERVO46 46
#define SERVO47 47
#define SERVO48 48
#define SERVO49 49
#define SERVO50 50
#define SERVO51 51
#define SERVO52 52
#define SERVO53 53
#define SERVO54 54
#define SERVO55 55
#define SERVO56 56
#define SERVO57 57
#define SERVO58 58
#define SERVO59 59
#define SERVO60 60
#define SERVO61 61
#define SERVO62 62
#define SERVO63 63

#define L 9600
#define H 115200
#define M 19200

#define ENABLE true
#define DISABLE false


#define MIN_PULSE_WIDTH       544     // the shortest pulse sent to a servo  
#define MAX_PULSE_WIDTH      2400     // the longest pulse sent to a servo 
#define DEFAULT_PULSE_WIDTH  1500     // default pulse width when servo is attached

class eGizmo_16channelServo
{
public:
	eGizmo_16channelServo(SoftwareSerial *ss);
	eGizmo_16channelServo(uint8_t rxPin, uint8_t txPin);
	eGizmo_16channelServo(HardwareSerial *hs);

	void begin(uint32_t baudrate = 9600);
	void end(void);
	void debugMode(bool stat);

	void moveServo(int servoNum, int freq, int slew = 50);
	void sleep(void);
	bool isServoActive(int servoNum, long timeOut = 500);
	bool isDriverActive(int driverNum, long timeOut = 500);

	void changeBaudrate(uint32_t baudrate);

private:
	bool DEBUG;
	Stream *mySerial;

	HardwareSerial *hwSerial;
	SoftwareSerial *swSerial;
	void manualSend(String cmd);
	void write(String cmd);
};
#endif