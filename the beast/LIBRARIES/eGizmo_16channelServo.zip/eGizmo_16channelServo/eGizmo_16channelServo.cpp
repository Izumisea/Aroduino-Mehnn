#include <Arduino.h> 

#include <eGizmo_16channelServo.h>
#include <SoftwareSerial.h>

bool DEBUG = false;

eGizmo_16channelServo::eGizmo_16channelServo (SoftwareSerial *ss) {
  hwSerial = NULL;
  swSerial = ss;
  mySerial = swSerial;
}

eGizmo_16channelServo::eGizmo_16channelServo (HardwareSerial *hs) {
  swSerial = NULL;
  hwSerial = hs;  
  mySerial = hwSerial;
}

void eGizmo_16channelServo::begin(uint32_t baudrate) {

  delay(1000);  // one second delay to let the module 'boot up'

  if (baudrate == L || baudrate == M || baudrate == H)
  {
  
   if (hwSerial) hwSerial->begin(baudrate);

   if (swSerial) swSerial->begin(baudrate);
  
  }else{
  
    if (hwSerial) hwSerial->begin(9600);

    if (swSerial) swSerial->begin(9600);
  }


}

void eGizmo_16channelServo::changeBaudrate(uint32_t baudrate) {

  if (hwSerial) hwSerial->end();

  if (swSerial) swSerial->end();

    switch(baudrate){
      case 9600:
        write("L");
        baudrate = 9600;
      break;
      
      case 19200:
        write("M");
        baudrate = 19200;
      break;
      
      case 115200:
        write("H");
        baudrate = 115200;
      break;

      default:
       write("L");
       baudrate = 9600;
      }

    if (hwSerial) hwSerial->end();

    if (swSerial) swSerial->end();
      
    if (hwSerial) hwSerial->begin(baudrate);

    if (swSerial) swSerial->begin(baudrate);

}

void eGizmo_16channelServo::end(void) {
  if (hwSerial) hwSerial->end();

  if (swSerial) swSerial->end();
}

void eGizmo_16channelServo::debugMode(bool stat){
  DEBUG = stat;
  if(DEBUG && !(hwSerial)){
    hwSerial = &Serial;
    hwSerial->begin(9600);
  }  
}

void eGizmo_16channelServo::moveServo(int servoNum, int freq, int slew) {
  String commander = "";
  int value = freq;

  if(value < 0) value = 0;
    if(value > 180 && value < MIN_PULSE_WIDTH) value = 180;

  commander = String(servoNum);
  commander += ",";

  if(value >= MIN_PULSE_WIDTH){
      commander += String(value);
    }else{
         value = map(value, 0, 180, MIN_PULSE_WIDTH,  MAX_PULSE_WIDTH);

      commander += String(value);
    }
  
  commander += ",";
  commander += String(slew);  
  if(DEBUG){
    hwSerial->print(F("Servo Number:\t")); hwSerial->println(servoNum);
    hwSerial->print(F("Angle Write:\t")); hwSerial->println(freq);
    hwSerial->print(F("Slew Increment:\t")); hwSerial->println(slew);
    hwSerial->print(F("Actual Frequency:\t")); hwSerial->println(value);
    hwSerial->print(F("Command Sent:\t")); hwSerial->println(commander);
  }
  write(commander);
}

void eGizmo_16channelServo::sleep(void){
  write("R");
}

bool eGizmo_16channelServo::isServoActive(int servoNum, long timeOut){
  String commander = "";
  bool stringComplete = false;
  String response = "";

  commander = String(servoNum);
  commander += ",";
  commander += "s";
  
  if(DEBUG){
    hwSerial->print(F("Command Sent:")); hwSerial->println(commander);
  }  
  
  write(commander);
  long timer = 0;
  while(!stringComplete || timer >= timeOut)
  {
    while(mySerial->available())
    {
      char c = (char)mySerial->read(); // read the next character.
      if (c == sufFix)
      {
        stringComplete = true;
      }
      if (c != preFix && c != sufFix)
      {
         response += c;
      }
    }
    timer++;  
  }
  if (response == "1")
  {
    return false;
  }else{ 
    return true;
  }
}

bool eGizmo_16channelServo::isDriverActive(int driverNum, long timeOut){
  String commander = "";
  bool stringComplete = false;
  String response = "";

  commander = String(driverNum);
  commander += ",";
  commander += "S";

  if(DEBUG){
    hwSerial->print(F("Command Sent:")); hwSerial->println(commander);
  }  
  
  write(commander);
    
  long timer = 0;
  while(!stringComplete || timer >= timeOut)
  {
    while(mySerial->available())
    {
      char c = (char)mySerial->read(); // read the next character.
      if (c == sufFix)
      {
        stringComplete = true;
      }
      if (c != preFix && c != sufFix)
      {
         response += c;
      }
    }
    timer++;  
  }
  if(DEBUG){
    hwSerial->print(F("Driver Response:")); hwSerial->println(response);
  }
  if (response == "1")
  {
    return false;
  }else{ 
    return true;
  }
}

void eGizmo_16channelServo::write(String cmd){
  mySerial->write(preFix);
  delay(2);// essential
  mySerial->print(cmd);
  delay(2);// essential
  mySerial->write(sufFix);
  delay(2);// essential
}

void eGizmo_16channelServo::manualSend (String cmd){
  mySerial->print(cmd);
  delay(2);// essential
}



